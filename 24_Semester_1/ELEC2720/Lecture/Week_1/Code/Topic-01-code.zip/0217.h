// 0217.h
extern int number;
