/* 0101.c
   A first program in C */
#include <stdio.h>

/* function main begins program execution */
int main( void )
{
    printf( "Hello world!\n" );
    
    return 0; /* indicate that program ended successfully */
} /* end function main */

