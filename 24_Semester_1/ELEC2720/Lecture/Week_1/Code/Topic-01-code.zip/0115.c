// 0115.c
#include <stdio.h>

int main(void) {
   int counter = 1; // initialize counter

   do {
      printf("%d  ", counter);
   } while (++counter <= 5);
}
