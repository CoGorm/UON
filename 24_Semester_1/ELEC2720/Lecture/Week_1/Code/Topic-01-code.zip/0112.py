# 0112.py

for counter in range(10):
    print("Loop: ", counter)
    counter = counter + 2
    print("Increase: ", counter)
