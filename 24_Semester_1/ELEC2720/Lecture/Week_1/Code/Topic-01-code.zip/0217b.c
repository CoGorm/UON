// 0217b.c
#include <stdio.h>
#include "0217.h" // This copy the content of "0217.h" here

int main (void) {
    printf("Number is %d\n", number);
}
