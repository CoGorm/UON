// 0112a.c
#include <stdio.h>

int main(void) {
   for (int counter = 0; counter <= 9; ++counter) {
      printf("Loop: %d\n", counter);
   }
}
