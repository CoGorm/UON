// 0111.c
#include <stdio.h>

int main(void) {
   for (int counter = 1; counter <= 5; ++counter) {
      printf("%d  ", counter);
   }
   puts(""); // outputs a newline
}
