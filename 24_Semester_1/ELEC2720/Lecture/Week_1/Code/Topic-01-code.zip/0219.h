// 0219.h
int square(int number); // Function declaration by default global. No need 'extern'
