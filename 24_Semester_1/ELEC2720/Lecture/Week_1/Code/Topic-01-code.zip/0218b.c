// 0218b.c
#include <stdio.h>

extern int number;

int main (void) {
    printf("Number is %d\n", number);
}
