// 0218a.c
int number = 1234;
