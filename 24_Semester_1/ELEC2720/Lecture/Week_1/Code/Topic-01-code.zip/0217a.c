// 0217a.c
int number = 1234;
