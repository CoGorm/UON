# 0112a.py

for counter in range(10):
    print("Loop: ", counter)
