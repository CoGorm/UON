// 0219b.c
int square(int number) { // number is a copy of the function's argument 
   return number * number; // returns square of number as an int        
}                                                                       
