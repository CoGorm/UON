// 0216b.c
#include <stdio.h>

int main (void) {
    printf("Number is %d\n", number);
}
