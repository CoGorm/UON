"""
0101.py
A first program in Python
"""
print("Hello world!")
