// 0216a.c
int number = 1234;
