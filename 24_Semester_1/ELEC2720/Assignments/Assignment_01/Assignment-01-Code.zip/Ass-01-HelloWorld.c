// Ass-01-HelloWorld.c

#include <stdio.h>
int main (void)
{
    printf("Hello World.\n"); /* Print a string */

    int a = 1;

    printf("The number is %d.\n", a); /* Print formatted output */
    
    return 0;
}
