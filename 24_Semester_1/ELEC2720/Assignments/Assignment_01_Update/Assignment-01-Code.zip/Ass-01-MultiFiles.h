// Ass-01-MultiFiles.h 

#ifndef ASS_01_MULTIFILES_H_
#define ASS_01_MULTIFILES_H_

extern int a;
void increaseA(void);

#endif /* ASS_01_MULTIFILES_H_ */
