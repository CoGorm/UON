// Ass-01-MultiFiles1.c

#include <stdio.h>
#include "Ass-01-MultiFiles.h"

int main () {
    printf("a = %d\n", a);
    increaseA();
    printf("a = %d\n", a);
    return 0;
}
