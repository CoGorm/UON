// Ass-01-MultiFiles2.c

int a = 0;

void increaseA (void) {
    a++;
}
